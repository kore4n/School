#ifndef CHECKPASSWORD_H
#define CHECKPASSWORD_H
int checkPassword(const char * password, int start);

#endif

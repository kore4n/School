#include "election_riding.h"
#include "election_candidate.h"

void print_help(void);

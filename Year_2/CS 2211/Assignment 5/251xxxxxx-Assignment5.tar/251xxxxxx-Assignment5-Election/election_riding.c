#include "election_riding.h"

/* dump: Dumps contents of the riding_tbl to specified
 *       file. Prints error message and does not
 *       terminate program upon failure. Does not store
 *       next pointer.
 */
void dump_riding(struct riding **riding_tbl)
{
    FILE *fp;
    char filename[255];
    struct riding **node = riding_tbl;

    printf("Enter name of output file: ");
    read_line(filename, 255);

    if ((fp = fopen(filename, "wb")) == NULL)
    {
        fprintf(stderr, "File %s could not be written\n", filename);
        return;
    }

    while (*node)
    {
        fwrite(*node, sizeof(struct riding) - sizeof(struct riding *), 1, fp);
        node = &(*node)->next;
    }
    fclose(fp);
    return;
}

/* restore: Restores contents from specified file. Does
 *          not terminate upon file open failure, but
 *          terminates upon malloc failure.
 */
void restore_riding(struct riding **riding_tbl)
{
    FILE *fp;
    char filename[255];
    struct riding buffer;
    struct riding *temp;
    struct riding **node;

    printf("Enter name of input file: ");
    read_line(filename, 255);

    if ((fp = fopen(filename, "rb")) == NULL)
    {
        fprintf(stderr, "Error: file %s cannot be opened\n", filename);
        return;
    }

    while (*riding_tbl)
    {
        temp = *riding_tbl;
        *riding_tbl = (*riding_tbl)->next;
        free(temp);
    }

    node = riding_tbl;

    while (fread(&buffer,sizeof(struct riding) - sizeof(struct riding *),1,fp) == 1)
    {
        if ((*node = malloc(sizeof(struct riding))) == NULL)
        {
            fprintf(stderr, "Error: malloc failed in restore\n");
            exit(EXIT_FAILURE);
        }
        (*node)->number = buffer.number;
        strcpy((*node)->name, buffer.name);
        (*node)->riding_size = buffer.riding_size;
        (*node)->gender = buffer.gender;
        (*node)->next = NULL;
        node = &(*node)->next;
    }
    fclose(fp);
    return;
}

//To be implemented

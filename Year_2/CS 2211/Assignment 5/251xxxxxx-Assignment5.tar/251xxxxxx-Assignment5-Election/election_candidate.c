#include "election_candidate.h"

/* dump: Dumps contents of the candidate_tbl to specified
 *       file. Prints error message and does not
 *       terminate program upon failure. Does not store
 *       next pointer.
 */
void dump_candidate(struct candidate **candidate_tbl)
{
    FILE *fp;
    char filename[255];
    struct candidate **node = candidate_tbl;

    printf("Enter name of output file: ");
    read_line(filename, 255);

    if ((fp = fopen(filename, "wb")) == NULL)
    {
        fprintf(stderr, "File %s could not be written\n", filename);
        return;
    }

    while (*node)
    {
        fwrite(*node, sizeof(struct candidate) - sizeof(struct candidate *), 1, fp);
        node = &(*node)->next;
    }
    fclose(fp);
    return;
}

/* restore: Restores contents from specified file. Does
 *          not terminate upon file open failure, but
 *          terminates upon malloc failure.
 */
void restore_candidate(struct candidate **candidate_tbl)
{
    FILE *fp;
    char filename[255];
    struct candidate buffer;
    struct candidate *temp;
    struct candidate **node;

    printf("Enter name of input file: ");
    read_line(filename, 255);

    if ((fp = fopen(filename, "rb")) == NULL)
    {
        fprintf(stderr, "Error: file %s cannot be opened\n", filename);
        return;
    }

    while (*candidate_tbl)
    {
        temp = *candidate_tbl;
        *candidate_tbl = (*candidate_tbl)->next;
        free(temp);
    }

    node = candidate_tbl;

    while (fread(&buffer,sizeof(struct candidate) - sizeof(struct candidate *),1,fp) == 1)
    {
        if ((*node = malloc(sizeof(struct candidate))) == NULL)
        {
            fprintf(stderr, "Error: malloc failed in restore\n");
            exit(EXIT_FAILURE);
        }
        (*node)->number = buffer.number;
        strcpy((*node)->name, buffer.name);
        (*node)->age = buffer.age;
        (*node)->party = buffer.party;
        (*node)->next = NULL;
        node = &(*node)->next;
    }
    fclose(fp);
    return;
}

//To be implemented

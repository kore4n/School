/*********************************************************
 * From C PROGRAMMING: A MODERN APPROACH, Second Edition *
 * By K. N. King                                         *
 * Copyright (c) 2008, 1996 W. W. Norton & Company, Inc. *
 * All rights reserved.                                  *
 * This program may be freely distributed for class use, *
 * provided that this copyright notice is retained.      *
 *********************************************************/

/* Adopted from inventory2.c (Chapter 17, page 434) by Will Beldman */
/* Maintains an Election database (linked list version) */

#include "election_db.h"


int main(void)
{
    struct riding *riding_tbl = NULL;   /* points to first riding */
    struct candidate *candidate_tbl = NULL;   /* points to first candidate */

    char entity, code;
    printf("*****************\n");
    printf("* 2211 Election *\n");
    printf("*****************\n\n\n");

    for (;;) {
        printf("Enter entity type (h for help, q to quit, e for riding, c for candidates): ");
        scanf(" %c", &entity);
        while (getchar() != '\n')   /* skips to end of line */
        ;
        if (entity == 'h'){
            print_help();
        }
        else if (entity == 'r'){
            printf("Event:\n\t");
            printf("Enter operation code\n\t(i to insert, s to search,\n\tu to update, p to print,\n\td to dump, r to restore,\n\te to erase): ");
            scanf(" %c", &code);
            while (getchar() != '\n')   /* skips to end of line */
                ;

            switch (code) {
                case 'i': insert_riding(&riding_tbl);
                            break;
                case 's': search_riding(&riding_tbl);
                            break;
                case 'u': update_riding(&riding_tbl);
                            break;
                case 'p': print_riding(&riding_tbl);
                            break;
                case 'd': dump_riding(&riding_tbl);
                            break;
                case 'r': restore_riding(&riding_tbl);
                            break;
                case 'e': erase_riding(&riding_tbl);
                            break;
                default:  printf("Illegal code\n");
            }
        }
        else if (entity == 'c'){
            printf("Athlete:\n\t");
            printf("Enter operation code\n\t(i to insert, s to search,\n\tu to update, p to print,\n\td to dump, r to restore,\n\te to erase): ");
            scanf(" %c", &code);
            while (getchar() != '\n')   /* skips to end of line */
                ;

            switch (code) {
                case 'i': insert_candidate(&candidate_tbl);
                            break;
                case 's': search_candidate(&candidate_tbl);
                            break;
                case 'u': update_candidate(&candidate_tbl);
                            break;
                case 'p': print_candidate(&candidate_tbl);
                            break;
                case 'd': dump_candidate(&candidate_tbl);
                            break;
                case 'r': restore_candidate(&candidate_tbl);
                            break;
                case 'e': erase_candidate(&candidate_tbl);
                            break;
                default:  printf("Illegal code\n");
            }
        }
        else if (entity == 'q'){
            return 0;
        }
        else{
            printf("Illegal entity\n");
        }
        printf("\n");
    }
}

void print_help(void){
    printf("\nEnter r for riding, c for candidate, then\n");
    printf("Enter operation code\n\t(i to insert, s to search,\n\tu to update, p to print,\n\td to dump, r to restore,\n\te to erase)\n\n ");
}
